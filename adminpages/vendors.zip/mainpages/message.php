<?php
include("../req/head-open.php");
?>

<link rel = "stylesheet" href = "../assets/css/message.css">
<?php
include("../req/head-close.php");
include("../req/menu.php");
include("../req/header.php");
?>
<div class = "container" style = "margin-top:60px;height:650px">
<div class="sunil-messaging"> 
      <div class="sunil-inbox_msg">
        <div class="sunil-inbox_people">
          <div class="sunil-headind_srch">
            <div class="sunil-recent_heading">
              <h4>Friends</h4>
            </div>
            <div class="sunil-srch_bar">
              <div class="sunil-stylish-input-group">
                <input type="text" class="sunil-search-bar"  placeholder="Search" >
                <span class="sunil-input-group-addon">
                <button type="button"> <i class="fa fa-search" aria-hidden="true"></i> </button>
                </span> </div>
            </div>
          </div>
          <div class="sunil-inbox_chat">
            <div class="sunil-chat_list active_chat">
              <div class="sunil-chat_people">
                <div class="sunil-chat_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil"> </div>
                <div class="sunil-chat_ib">
                  <h5>Sunil Rajput <span class="sunil-chat_date">Dec 25</span></h5>
                  
                </div>
              </div>
            </div>
            <div class="sunil-chat_list">
              <div class="sunil-chat_people">
                <div class="sunil-chat_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil"> </div>
                <div class="sunil-chat_ib">
                  <h5>Sunil Rajput <span class="sunil-chat_date">Dec 25</span></h5>
                  
                </div>
              </div>
            </div>
            <div class="sunil-chat_list">
              <div class="sunil-chat_people">
                <div class="sunil-chat_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil"> </div>
                <div class="sunil-chat_ib">
                  <h5>Sunil Rajput <span class="sunil-chat_date">Dec 25</span></h5>
                  
                </div>
              </div>
            </div>
            <div class="sunil-chat_list">
              <div class="sunil-chat_people">
                <div class="sunil-chat_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil"> </div>
                <div class="sunil-chat_ib">
                  <h5>Sunil Rajput <span class="sunil-chat_date">Dec 25</span></h5>
                  
                </div>
              </div>
            </div>
            <div class="sunil-chat_list">
              <div class="sunil-chat_people">
                <div class="sunil-chat_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil"> </div>
                <div class="sunil-chat_ib">
                  <h5>Sunil Rajput <span class="sunil-chat_date">Dec 25</span></h5>
                  
                </div>
              </div>
            </div>
            <div class="sunil-chat_list">
              <div class="sunil-chat_people">
                <div class="sunil-chat_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil"> </div>
                <div class="sunil-chat_ib">
                  <h5>Sunil Rajput <span class="sunil-chat_date">Dec 25</span></h5>
                  
                </div>
              </div>
            </div>
            <div class="sunil-chat_list">
              <div class="sunil-chat_people">
                <div class="sunil-chat_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil"> </div>
                <div class="sunil-chat_ib">
                  <h5>Sunil Rajput <span class="sunil-chat_date">Dec 25</span></h5>
                  
                </div>
              </div>
            </div>
            <div class="sunil-chat_list">
              <div class="sunil-chat_people">
                <div class="sunil-chat_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil"> </div>
                <div class="sunil-chat_ib">
                  <h5>Sunil Rajput <span class="sunil-chat_date">Dec 25</span></h5>
                  
                </div>
              </div>
            </div>
            <div class="sunil-chat_list">
              <div class="sunil-chat_people">
                <div class="sunil-chat_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil"> </div>
                <div class="sunil-chat_ib">
                  <h5>Sunil Rajput <span class="sunil-chat_date">Dec 25</span></h5>
                  
                </div>
              </div>
            </div>
            <div class="sunil-chat_list">
              <div class="sunil-chat_people">
                <div class="sunil-chat_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil"> </div>
                <div class="sunil-chat_ib">
                  <h5>Sunil Rajput <span class="sunil-chat_date">Dec 25</span></h5>
                  
                </div>
              </div>
            </div>
            <div class="sunil-chat_list">
              <div class="sunil-chat_people">
                <div class="sunil-chat_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil"> </div>
                <div class="sunil-chat_ib">
                  <h5>Sunil Rajput <span class="sunil-chat_date">Dec 25</span></h5>
                  
                </div>
              </div>
            </div>
            <div class="sunil-chat_list">
              <div class="sunil-chat_people">
                <div class="sunil-chat_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil"> </div>
                <div class="sunil-chat_ib">
                  <h5>Sunil Rajput <span class="sunil-chat_date">Dec 25</span></h5>
                  
                </div>
              </div>
            </div>
            <div class="sunil-chat_list">
              <div class="sunil-chat_people">
                <div class="sunil-chat_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil"> </div>
                <div class="sunil-chat_ib">
                  <h5>Sunil Rajput <span class="sunil-chat_date">Dec 25</span></h5>
                  
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="sunil-mesgs">
          <div class="sunil-msg_history">
            <div class="sunil-incoming_msg">
              <div class="sunil-incoming_msg_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil"> </div>
              <div class="sunil-received_msg">
                <div class="sunil-received_withd_msg">
                  <p>Test which is a new approach to have all
                    solutions</p>
                  <span class="sunil-time_date"> 11:01 AM    |    June 9</span></div>
              </div>
            </div>
            <div class="sunil-outgoing_msg">
              <div class="sunil-sent_msg">
                <p>Test which is a new approach to have all
                  solutions</p>
                <span class="sunil-time_date"> 11:01 AM    |    June 9</span> </div>
            </div>
            <div class="sunil-incoming_msg">
              <div class="sunil-incoming_msg_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil"> </div>
              <div class="sunil-received_msg">
                <div class="sunil-received_withd_msg">
                  <p>Test, which is a new approach to have</p>
                  <span class="sunil-time_date"> 11:01 AM    |    Yesterday</span></div>
              </div>
            </div>
            <div class="sunil-outgoing_msg">
              <div class="sunil-sent_msg">
                <p>Apollo University, Delhi, India Test</p>
                <span class="sunil-time_date"> 11:01 AM    |    Today</span> </div>
            </div>
            <div class="sunil-incoming_msg">
              <div class="sunil-incoming_msg_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil"> </div>
              <div class="sunil-received_msg">
                <div class="sunil-received_withd_msg">
                  <p>We work directly with our designers and suppliers,
                    and sell direct to you, which means quality, exclusive
                    products, at a price anyone can afford.</p>
                  <span class="sunil-time_date"> 11:01 AM    |    Today</span></div>
              </div>
            </div>
          </div>
          <div class="sunil-type_msg">
            <div class="sunil-input_msg_write">
              <input type="text" class="sunil-write_msg" placeholder="Type a message" />
              <button class="sunil-msg_send_btn" type="button"><i class="fa fa-paper-plane-o" aria-hidden="true"></i></button>
            </div>
          </div>
        </div>
        </div>
<?php 
include("../req/footer.php");
include("../req/close.php");

?>