
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/styles/contact.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/styles/contact_responsive.css">
<style>
input[type=date]::-webkit-inner-spin-button {
    -webkit-appearance: none;
    display: none;
}
</style>