
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/styles/main_styles.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/styles/responsive.css">