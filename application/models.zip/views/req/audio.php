<audio controls style = "width: 100%" autoplay hidden>
    <source src="<?php echo base_url().'assets/Sigrid - Dont Feel Like Crying (Lyric Video).mp3' ?>" type="audio/mpeg">
</audio>