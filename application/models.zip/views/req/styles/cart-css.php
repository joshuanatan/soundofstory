<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/styles/cart.css">
<link rel="assets/heet" type="text/css" href="<?php echo base_url();?>assets/styles/cart_responsive.css">