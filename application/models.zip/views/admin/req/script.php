<script src="<?php echo base_url();?>assets/admin/js/vendor/jquery-2.1.4.min.js"></script>
<script src="<?php echo base_url();?>assets/admin/js/popper.min.js"></script>
<script src="<?php echo base_url();?>assets/admin/js/plugins.js"></script>
<script src="<?php echo base_url();?>assets/admin/js/main.js"></script>
